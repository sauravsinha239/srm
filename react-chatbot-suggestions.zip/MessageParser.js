
import React from 'react';
import Fuse from 'fuse.js';

const MessageParser = ({ children, actions, apiData }) => {
  const fuse = new Fuse(apiData, {
    keys: ['Label'],
    threshold: 0.4,
    ignoreLocation: true,
  });

  const normalize = (str) =>
    str.toLowerCase().replace(/[^\w\s]/gi, '').trim();

  const parse = (message) => {
    const msg = normalize(message);

    if (msg === "") {
      actions.handleMenuResponse("Please type something.");
      return;
    }

    const results = fuse.search(msg);

    if (results.length > 0) {
      if (msg.length < 3) {
        const suggestions = results.slice(0, 5).map(res => res.item.Label);
        actions.handleSuggestions(suggestions);
      } else {
        const topResults = results.slice(0, 3);
        topResults.forEach(result => {
          const item = result.item;
          actions.handleMenuResponse(`${item.Label}:\n${item.Description}`);
        });
      }
    } else {
      actions.handleMenuResponse("Sorry, I couldn't find that.");
    }
  };

  return (
    <>
      {React.Children.map(children, (child) =>
        React.cloneElement(child, { parse, actions })
      )}
    </>
  );
};

export default MessageParser;
