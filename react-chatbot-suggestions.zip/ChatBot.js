
import React, { useState } from 'react';
import './ChatBot.css';

const ChatBot = ({ messages, setMessages, suggestions, actions, parse }) => {
  const [input, setInput] = useState("");

  const handleSend = () => {
    if (input.trim() === "") return;
    setMessages(prev => [...prev, { type: 'user', text: input }]);
    parse(input);
    setInput("");
  };

  return (
    <div className="chat-container">
      <div className="chat-box">
        {messages.map((msg, idx) => (
          <div key={idx} className={\`chat-message \${msg.type}\`}>
            {msg.text}
          </div>
        ))}
        {suggestions.length > 0 && (
          <div className="suggestion-box">
            {suggestions.map((sugg, idx) => (
              <button key={idx} className="suggestion-btn" onClick={() => parse(sugg)}>
                {sugg}
              </button>
            ))}
          </div>
        )}
      </div>
      <div className="input-box">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Type a message..."
        />
        <button onClick={handleSend}>Send</button>
      </div>
    </div>
  );
};

export default ChatBot;
