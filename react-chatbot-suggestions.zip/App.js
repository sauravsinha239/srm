
import React, { useState } from 'react';
import MessageParser from './MessageParser';
import ChatBot from './ChatBot';

const apiData = [
  { Label: 'Reset Password', Description: 'Follow these steps to reset your password...' },
  { Label: 'Register', Description: 'Click here to register a new account...' },
  { Label: 'Restart', Description: 'Steps to restart your device...' },
  { Label: 'Refund', Description: 'Process to request a refund...' },
  { Label: 'Report Issue', Description: 'Here is how to report an issue...' },
];

const App = () => {
  const [messages, setMessages] = useState([]);
  const [suggestions, setSuggestions] = useState([]);

  const actions = {
    handleMenuResponse: (response) => {
      setMessages(prev => [...prev, { type: 'bot', text: response }]);
      setSuggestions([]);
    },
    handleSuggestions: (list) => {
      setSuggestions(list);
    },
  };

  return (
    <MessageParser actions={actions} apiData={apiData}>
      <ChatBot messages={messages} setMessages={setMessages} suggestions={suggestions} actions={actions} />
    </MessageParser>
  );
};

export default App;
