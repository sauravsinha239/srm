const express = require('express');
const cors = require('cors');
const db = require('./db');

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

// Route to get all FAQs
app.get('/faqs', (req, res) => {
  const sql = 'SELECT id, question, answer FROM faqs';
  db.query(sql, (err, results) => {
    if (err) {
      console.error('Error fetching FAQs: ', err);
      res.status(500).json({ error: 'Failed to fetch FAQs' });
    } else {
      res.json(results);
    }
  });
});

// Health Check
app.get('/', (req, res) => {
  res.send('FAQ Backend Running...');
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
