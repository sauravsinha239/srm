class MessageParser {
  constructor(actionProvider) {
    this.actionProvider = actionProvider;
  }

  parse(message) {
    // Not needed as user clicks button
  }
}

export default MessageParser;
