import axios from "axios";
import { createChatBotMessage } from "react-chatbot-kit";

class ActionProvider {
  constructor(createChatBotMessage, setStateFunc) {
    this.createChatBotMessage = createChatBotMessage;
    this.setState = setStateFunc;
  }

  async fetchFAQs() {
    try {
      const response = await axios.get('http://localhost:5000/api/faqs');
      const faqs = response.data;

      const buttons = faqs.map(faq => ({
        text: faq.question,
        handler: () => {
          const message = this.createChatBotMessage(faq.answer);
          this.setState(prev => ({
            ...prev,
            messages: [...prev.messages, message]
          }));
        },
        id: faq.id
      }));

      const message = this.createChatBotMessage("Select your question:", {
        widget: "faqButtons"
      });

      this.setState(prev => ({
        ...prev,
        messages: [...prev.messages, message],
        faqs: buttons
      }));

    } catch (error) {
      console.error('Error fetching FAQs:', error);
    }
  }
}

export default ActionProvider;