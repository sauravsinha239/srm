import { createChatBotMessage } from "react-chatbot-kit";
import FAQBot from "./FAQBot";

const config = {
  initialMessages: [createChatBotMessage("Hi! Select a question below.")],
  widgets: [
    {
      widgetName: "faqBot",
      widgetFunc: (props) => <FAQBot {...props} />,
    },
  ],
};

export default config;
